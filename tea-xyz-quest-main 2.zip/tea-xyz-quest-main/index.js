module.exports = function() {
  console.log('tea.xyz');
  return;
};
